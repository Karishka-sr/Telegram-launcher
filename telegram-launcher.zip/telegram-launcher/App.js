import React from 'react';
import {
  Image,
  Linking,
  PlatformColor,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  View,
  useColorScheme,
} from 'react-native';
import { expo } from './app.json';

const PLAY_APP = 'market://details?id=org.telegram.messenger';
const PLAY_WEB = 'https://play.google.com/store/apps/details?id=org.telegram.messenger';

async function launchTelegram() {
  try {
    await Linking.openURL('tg://');
  } catch {
    try {
      await Linking.openURL(PLAY_APP);
    } catch {
      await Linking.openURL(PLAY_WEB);
    }
  }
}

// Material You: системные цвета Android 12+ (из обоев), запасная палитра для старых версий.
function useColors() {
  const dark = useColorScheme() === 'dark';
  const you = Platform.OS === 'android' && Platform.Version >= 31;
  const sys = (name, fallback) => (you ? PlatformColor(`@android:color/${name}`) : fallback);
  return dark
    ? {
        background: sys('system_neutral1_900', '#1B1B1F'),
        primary: sys('system_accent1_200', '#A8C7FA'),
        onPrimary: sys('system_accent1_800', '#062E6F'),
        muted: sys('system_neutral2_200', '#C4C6D0'),
        ripple: '#00000033',
      }
    : {
        background: sys('system_neutral1_10', '#FDFBFF'),
        primary: sys('system_accent1_600', '#0B57D0'),
        onPrimary: sys('system_accent1_0', '#FFFFFF'),
        muted: sys('system_neutral2_700', '#44474F'),
        ripple: '#FFFFFF33',
      };
}

export default function App() {
  const c = useColors();
  const dark = useColorScheme() === 'dark';

  return (
    <View style={[styles.root, { backgroundColor: c.background }]}>
      <StatusBar barStyle={dark ? 'light-content' : 'dark-content'} backgroundColor="transparent" translucent />
      <View style={styles.center}>
        <Image source={require('./assets/telegram.png')} style={styles.logo} />
        <Pressable
          onPress={launchTelegram}
          android_ripple={{ color: c.ripple }}
          style={[styles.button, { backgroundColor: c.primary }]}
        >
          <Text style={[styles.label, { color: c.onPrimary }]}>Включить Telegram</Text>
        </Pressable>
      </View>
      <Text style={[styles.version, { color: c.muted }]}>v{expo.version}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, paddingHorizontal: 24, paddingTop: 48, paddingBottom: 32, justifyContent: 'space-between' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 40 },
  logo: { width: 120, height: 120 },
  button: { height: 56, paddingHorizontal: 32, borderRadius: 28, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  label: { fontSize: 16, fontWeight: '600', letterSpacing: 0.1 },
  version: { fontSize: 12 },
});
